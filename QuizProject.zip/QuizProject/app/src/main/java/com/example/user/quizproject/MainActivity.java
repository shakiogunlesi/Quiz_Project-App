package com.example.user.quizproject;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import static com.example.user.quizproject.R.id.name_field;

public class MainActivity extends AppCompatActivity {
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Get the id of the button that submits the quiz

    }

    public void submitOrder (View view){

        EditText name_Field = (EditText)findViewById(name_field);
        String name = name_Field.getText().toString();

        RadioGroup radio1 = (RadioGroup) findViewById(R.id.question_1);
        int solution1 = radio1.getCheckedRadioButtonId();

        if (solution1 == R.id.answer_1){
            score += 10;
        }
        else{
            score += 0;
        }

        RadioGroup radio2 = (RadioGroup) findViewById(R.id.question_2);
        int solution2 = radio2.getCheckedRadioButtonId();

        if (solution2 == R.id.answer_3){
            score += 10;
        }
        else{
            score += 0;
        }

        RadioGroup radio3 = (RadioGroup) findViewById(R.id.question_3);
        int solution3 = radio3.getCheckedRadioButtonId();

        if (solution3 == R.id.answer_5){
            score += 10;
        }
        else{
            score += 0;
        }

        RadioGroup radio4 = (RadioGroup) findViewById(R.id.question_4);
        int solution4 = radio4.getCheckedRadioButtonId();

        if (solution4 == R.id.answer_8){
            score += 10;
        }
        else{
            score += 0;
        }

        RadioGroup radio5 = (RadioGroup) findViewById(R.id.question_5);
        int solution5 = radio5.getCheckedRadioButtonId();

        if (solution5 == R.id.answer_9){
            score += 10;
        }
        else{
            score += 0;
        }



        Toast mee = Toast.makeText(getApplication(), name + " " + "your score is " + score, Toast.LENGTH_SHORT);
        mee.show();

    }

    public  void reset (View view){
        score = 0;
        RadioGroup radio1 = (RadioGroup) findViewById(R.id.question_1);
        radio1.clearCheck();

        RadioGroup radio2 = (RadioGroup) findViewById(R.id.question_2);
        radio2.clearCheck();

        RadioGroup radio3 = (RadioGroup) findViewById(R.id.question_3);
        radio3.clearCheck();

        RadioGroup radio4 = (RadioGroup) findViewById(R.id.question_4);
        radio4.clearCheck();

        RadioGroup radio5 = (RadioGroup) findViewById(R.id.question_5);
        radio5.clearCheck();


    }

}